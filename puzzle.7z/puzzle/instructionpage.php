<?php
include 'puzzlepage.php';
/**
 * Description of PuzzlePages
 *
 * @author Robert Walker
 */

class InstructionPage extends puzzlePage {
    
    protected function initPage() 
    {
        $this->pageno = 3;
        $this->pageTitle = "Instructions for the Game";
        $this->pageHeading = "Thank you for playing the puzzle game...";
        $this->pageBody = "How to play...</br>";
        $this->pageBody .= "<ul>";
            $this->pageBody .= "<li>The goal of this game is to arrange all of the tiles in order like so … </li>";
            $this->pageBody .= "</br><img src='solvedpuzzle.png'/>";
            $this->pageBody .= "<li>In order to make a move, just click on a tile and it will move to the open space on the puzzle board</li>";
            $this->pageBody .=  "<li>When the puzzle is solved you will be presented with another one.  The puzzles do not appear in any particular order of difficulty</li>";
            $this->pageBody .=  "<li>There is no time limit on the puzzle and they will be fun, not hard.  Try to complete the puzzle in as few moves as possible and as quickly as possible.</li>";
        $this->pageBody .= "</ul>";
        $this->pageBody .= "<p>";
        $this->pageBody .= "This game uses the Java plugin in your browser.  Please make sure that Java is enabled in your browser and that you allow the page to load the applet.  The applet will not try to collect your information, send you spam or download anything without your permission.  This should work with all browsers.  If you find any errors, please report them on our report page!";
    }
}
$p = new InstructionPage(true);
echo $p->getPageHTML();   
 
?>