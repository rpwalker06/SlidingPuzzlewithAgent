<?php

require 'puzzlepage.php';
/**
 * Description of PuzzlePages
 *
 * @author Robert Walker
 */
class WelcomePage extends puzzlePage {

    protected function initPage() 
    {
        $this->pageno = 2;
        $this->pageTitle = "Welcome to the Puzzle Game";
        $this->pageHeading = "Welcome...";
        $this->pageBody = "Thank you for participating in the Puzzle Game Study!  ";
        $this->pageBody .="We are investigating the effect that different types of interfaces have on how people play interactive games.  In this study you will attempt to solve a puzzle in as few moves as possible.  There will be an initial questionnaire that asks about your experience playing interactive games and solving puzzles.  Then you will have a chance to play the game.  After solving the puzzle a few times, you will fill out a small questionnaire and the study will conclude.  ";
        $this->pageBody .= "Thank you for participating and have fun!  ";
        //$this->pageBody .= "If you have any questions, feel free to drop us a line here.";
    }
}
$p = new WelcomePage(true);
echo $p->getPageHTML();

?>


