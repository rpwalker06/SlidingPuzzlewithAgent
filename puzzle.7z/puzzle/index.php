<?php
    session_start();
    require_once 'intropage.php';
    require_once 'puzzlesqlwriter.php';
    
    //convert into a submit button
    $_SESSION['participantid'] = puzzleSQLWriter::createParticipant();
    $_SESSION['agenttype'] = $_SESSION['participantid']%5;
    
    $p = new IntroPage(true);
    
    
    
    
?>
