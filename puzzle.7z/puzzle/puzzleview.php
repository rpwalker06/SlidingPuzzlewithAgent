<?php
session_start();
require 'puzzlepage.php';

class PuzzleView extends puzzlePage{
    
    public $experimenttype=0;
    
    public function initPage() 
    {
        $this->pageno = 5;
        $this->pageTitle = "Sliding 8 Puzzle!";
        $this->pageHeading = "Sliding 8 Puzzle";
        
        $this->overlaytext = $this->getOverlayText();
        
        $applet = new PageApplet("feedBackTest.puzzleApplet.class", "slidingPuzzleFeedback.jar");
        $applet->addParameter("participantid", $_SESSION['participantid']);
        $applet->addParameter("a", $_SERVER['HTTP_HOST']);
        $applet->addParameter("b", $_SESSION['participantid']);
        $applet->addParameter("c", $_SESSION['agenttype']);
        
        $this->pageBody= "Please try to solve each puzzle as quickly as you can.</br>";
        $this->pageBody.= $applet->getAppletHTML();
    }
    
    public function getOverlayText()
    {
        $echo="When you are ready to begin playing press the go button below. </br>
                Try to solve the puzzle using as few moves as possible";
        
        switch($this->experimenttype)
        {
            case 0:
                $echo.="";
                break;
            case 1:
                $echo.="To help you learn a strategy to solve the puzzle with the fewest moves, 
                        you will have a partner that will guide you on solving the puzzle.  
                        The partner will not be judging your performance or giving you a score.  
                        Rather the partner is there to guide you through the strategy with the fewest 
                        moves for the first 3 games.  For the last 2 games you will be able to play the game 
                        and solve the puzzle without the agent.";
                break;
            case 2:
                $echo.="To help you learn a strategy to solve the puzzle with the fewest moves, 
                        you will have a partner that will guide you on solving the puzzle.  
                        The partner will not be judging your performance or giving you a score.  
                        Rather the partner is there to guide you through the strategy with the fewest 
                        moves for the first 3 games.  For the last 2 games you will be able to play the game 
                        and solve the puzzle without the agent.";
                $echo.="The agent will respond to you using voice.  
                        Please make sure that you have headphones or another suitable means of audio output.";
                break;
        }
        return $echo;
    }
}

class PageApplet {
    
    private $appurl;
    private $jarurl;
    private $parameters;
    private $width=800;
    private $height=800;
    
    public function __construct($applet_url, $jar_url)
        {$this->appurl = $applet_url;
         $this->jarurl = $jar_url;
         $this->parameters = Array();
        }
        
    public function addParameter($name, $value)
    {
        $echo="";
        $echo.="<param name='" . $name . "' value='" . $value . "'>";
        $this->parameters[] = $echo;
    }
    
    public function getAppletHTML()
    {
        $echo="";
        $echo.="<applet code='" . $this->appurl . "' archive='". $this->jarurl ."' width='" . $this->width . "' height='" . $this->height .'">';
        
        foreach ($this->parameters as $parametertag)
            {$echo.=$parametertag;}
            
         $echo.="</applet>";
        
        return $echo;
    }
    
    public function setWidth($wide)
        {$this->width = $wide;}
    
    public function setHeight($high)
        {$this->height = $high;}
}
    $p = new PuzzleView(true);
    echo $_SESSION['agenttype'];
    echo $p->getPageHTML();
?>

